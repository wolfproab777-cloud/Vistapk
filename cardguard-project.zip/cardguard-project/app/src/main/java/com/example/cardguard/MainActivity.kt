package com.example.cardguard

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(modifier = Modifier.fillMaxSize()) { ScannerScreen() }
            }
        }
    }
}

@Composable
fun ScannerScreen() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var results by remember { mutableStateOf<List<ScanResult>?>(null) }
    var scanning by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .padding(16.dp)
    ) {
        Text("CardGuard", style = MaterialTheme.typography.headlineMedium)
        Text("Ilovalar xavfsizligini tekshirish", style = MaterialTheme.typography.bodyMedium)
        Spacer(Modifier.height(12.dp))

        Button(
            onClick = {
                scanning = true
                scope.launch {
                    results = withContext(Dispatchers.Default) { AppScanner.scan(context) }
                    scanning = false
                }
            },
            enabled = !scanning,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(if (scanning) "Tekshirilmoqda..." else "Skanerlash")
        }

        Spacer(Modifier.height(12.dp))

        results?.let { list ->
            val high = list.count { it.risk == Risk.HIGH }
            val medium = list.count { it.risk == Risk.MEDIUM }
            Text(
                "Jami: ${list.size} | Xavfli: $high | Shubhali: $medium",
                style = MaterialTheme.typography.titleSmall
            )
            Spacer(Modifier.height(8.dp))

            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(list.filter { it.risk != Risk.LOW }) { app ->
                    AppCard(app) {
                        // Foydalanuvchini ilova sozlamalariga yo'naltiramiz (o'chirishni o'zi hal qiladi)
                        val intent = Intent(
                            Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                            Uri.parse("package:${app.packageName}")
                        )
                        context.startActivity(intent)
                    }
                }
            }
        }
    }
}

@Composable
fun AppCard(app: ScanResult, onOpen: () -> Unit) {
    val color = when (app.risk) {
        Risk.HIGH -> Color(0xFFFFCDD2)
        Risk.MEDIUM -> Color(0xFFFFF3C4)
        Risk.LOW -> Color(0xFFC8E6C9)
    }
    val label = when (app.risk) {
        Risk.HIGH -> "XAVFLI"
        Risk.MEDIUM -> "SHUBHALI"
        Risk.LOW -> "XAVFSIZ"
    }

    Card(
        colors = CardDefaults.cardColors(containerColor = color),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(12.dp)) {
            Text(
                "${app.appName}  ·  $label (${app.score}/100)",
                style = MaterialTheme.typography.titleMedium,
                color = Color.Black
            )
            Text(app.packageName, style = MaterialTheme.typography.bodySmall, color = Color.DarkGray)
            Spacer(Modifier.height(6.dp))
            app.reasons.forEach {
                Text("• $it", style = MaterialTheme.typography.bodySmall, color = Color.Black)
            }
            Spacer(Modifier.height(8.dp))
            TextButton(onClick = onOpen) { Text("Sozlamalarni ochish / o'chirish") }
        }
    }
}
