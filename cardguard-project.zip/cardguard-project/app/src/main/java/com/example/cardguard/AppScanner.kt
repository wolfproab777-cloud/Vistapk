package com.example.cardguard

import android.accessibilityservice.AccessibilityServiceInfo
import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Build
import android.view.accessibility.AccessibilityManager

enum class Risk { LOW, MEDIUM, HIGH }

data class ScanResult(
    val appName: String,
    val packageName: String,
    val risk: Risk,
    val score: Int,
    val reasons: List<String>
)

object AppScanner {

    // ruxsat -> (tushuntirish, xavf bali)
    private val dangerousPermissions: Map<String, Pair<String, Int>> = mapOf(
        "android.permission.READ_SMS" to ("SMS xabarlarni o'qiy oladi (bank kodlarini ko'rishi mumkin)" to 30),
        "android.permission.RECEIVE_SMS" to ("Kelgan SMS larni ushlab oladi" to 20),
        "android.permission.SEND_SMS" to ("Sizning nomingizdan SMS yubora oladi" to 20),
        "android.permission.SYSTEM_ALERT_WINDOW" to ("Boshqa ilovalar ustida oyna chiqara oladi (soxta bank oynasi)" to 25),
        "android.permission.REQUEST_INSTALL_PACKAGES" to ("Boshqa ilovalarni o'rnata oladi" to 15),
        "android.permission.BIND_DEVICE_ADMIN" to ("Qurilma administratori bo'lishni so'raydi" to 25),
        "android.permission.READ_CALL_LOG" to ("Qo'ng'iroqlar tarixini o'qiydi" to 10),
        "android.permission.READ_CONTACTS" to ("Kontaktlaringizni o'qiydi" to 5),
        "android.permission.RECORD_AUDIO" to ("Mikrofondan foydalana oladi" to 5)
    )

    private val trustedInstallers = setOf(
        "com.android.vending",            // Google Play
        "com.sec.android.app.samsungapps", // Samsung Galaxy Store
        "com.huawei.appmarket",
        "com.xiaomi.mipicks",
        "com.amazon.venezia"
    )

    fun scan(context: Context): List<ScanResult> {
        val pm = context.packageManager

        val packages = if (Build.VERSION.SDK_INT >= 33) {
            pm.getInstalledPackages(
                PackageManager.PackageInfoFlags.of(PackageManager.GET_PERMISSIONS.toLong())
            )
        } else {
            @Suppress("DEPRECATION")
            pm.getInstalledPackages(PackageManager.GET_PERMISSIONS)
        }

        // Accessibility xizmati yoqilgan ilovalar (bank troyanlarining asosiy quroli)
        val am = context.getSystemService(Context.ACCESSIBILITY_SERVICE) as AccessibilityManager
        val a11yApps = am
            .getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)
            .map { it.resolveInfo.serviceInfo.packageName }
            .toSet()

        val results = mutableListOf<ScanResult>()

        for (pkg in packages) {
            val appInfo = pkg.applicationInfo ?: continue

            // Tizim ilovalarini o'tkazib yuboramiz
            val isSystem = (appInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0 &&
                (appInfo.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) == 0
            if (isSystem || pkg.packageName == context.packageName) continue

            val reasons = mutableListOf<String>()
            var score = 0
            val requested = pkg.requestedPermissions?.toSet() ?: emptySet()

            for ((perm, info) in dangerousPermissions) {
                if (perm in requested) {
                    reasons += info.first
                    score += info.second
                }
            }

            if (pkg.packageName in a11yApps) {
                reasons += "Accessibility xizmati YOQILGAN (ekranni o'qiy va bosa oladi)"
                score += 40
            }

            val smsAccess = "android.permission.READ_SMS" in requested ||
                "android.permission.RECEIVE_SMS" in requested
            val overlay = "android.permission.SYSTEM_ALERT_WINDOW" in requested
            if (smsAccess && overlay) {
                reasons += "SMS + ustki oyna birikmasi: bank troyani belgisi!"
                score += 20
            }

            if (installerOf(pm, pkg.packageName) !in trustedInstallers) {
                reasons += "Rasmiy do'kondan tashqarida o'rnatilgan"
                score += 15
            }

            score = score.coerceAtMost(100)
            val risk = when {
                score >= 60 -> Risk.HIGH
                score >= 30 -> Risk.MEDIUM
                else -> Risk.LOW
            }

            results += ScanResult(
                appName = pm.getApplicationLabel(appInfo).toString(),
                packageName = pkg.packageName,
                risk = risk,
                score = score,
                reasons = reasons
            )
        }

        return results.sortedByDescending { it.score }
    }

    private fun installerOf(pm: PackageManager, packageName: String): String? = try {
        if (Build.VERSION.SDK_INT >= 30) {
            pm.getInstallSourceInfo(packageName).installingPackageName
        } else {
            @Suppress("DEPRECATION")
            pm.getInstallerPackageName(packageName)
        }
    } catch (e: Exception) {
        null
    }
}
